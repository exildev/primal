<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$__file__ = realpath(__FILE__);
$__self__ = (str_replace('/', '\\', $_SERVER['DOCUMENT_ROOT'] . $_SERVER['PHP_SELF']));

if ($__file__ == $__self__) {
    header('HTTP/1.0 404 Not Found');
    header("Location: index.php");
}

/**
 * Description of oracle
 *
 * @author eXile
 */
class oracle {
    //put your code here
}

?>
